package com.checksac.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import java.util.Locale;

/** Widget man hinh chinh hien cong suat sac. Duoc cap nhat boi ChargeService (khong tu quet nen khong ton pin). */
public class ChargeWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        render(context, manager, appWidgetIds);
    }

    /** Cap nhat tat ca widget dang co tren man hinh (neu co). */
    static void refresh(Context c) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            int[] ids = m.getAppWidgetIds(new ComponentName(c, ChargeWidget.class));
            if (ids != null && ids.length > 0) render(c, m, ids);
        } catch (Exception ignored) {
        }
    }

    private static void render(Context c, AppWidgetManager m, int[] ids) {
        boolean enabled = c.getSharedPreferences(ChargeService.PREFS, Context.MODE_PRIVATE)
                .getBoolean(ChargeService.KEY_ENABLED, false);
        String big;
        String sub;
        int color;
        if (!enabled) {
            big = "TẮT";
            sub = "Mở app để bật";
            color = 0xFFFF5252;
        } else {
            PowerReader.Reading r = PowerReader.read(c);
            if (!r.plugged) {
                big = "-- W";
                sub = "Chưa cắm sạc";
                color = 0xFF9AA4AF;
            } else if (!r.valid) {
                big = "?";
                sub = "Không đọc được dòng sạc";
                color = 0xFFFFD60A;
            } else {
                big = String.format(Locale.US, "%.1f W", r.watts);
                sub = String.format(Locale.US, "%d mA · %.2f V", Math.round(r.milliAmps), r.volts);
                color = 0xFFFFD60A;
            }
        }

        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_charge);
        rv.setTextViewText(R.id.w_power, big);
        rv.setTextColor(R.id.w_power, color);
        rv.setTextViewText(R.id.w_sub, sub);
        PendingIntent pi = PendingIntent.getActivity(c, 2,
                new Intent(c, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        rv.setOnClickPendingIntent(R.id.w_root, pi);
        m.updateAppWidget(ids, rv);
    }
}
