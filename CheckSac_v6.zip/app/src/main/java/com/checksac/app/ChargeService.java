package com.checksac.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import java.util.Locale;

/**
 * Dich vu foreground cuc nhe:
 *  - Cam sac + man hinh bat  -> do moi 2 giay, hien "xxW" tren thanh trang thai (icon thong bao).
 *  - Rut sac hoac tat man hinh -> dung do hoan toan, an icon (khong ton CPU/pin).
 */
public class ChargeService extends Service {

    static final String PREFS = "cfg";
    static final String KEY_ENABLED = "enabled";
    static final String KEY_SHOW_W = "show_w";
    static final String KEY_OVERLAY = "overlay";
    static final String KEY_OV_SIZE = "ov_size";
    static final String KEY_OV_X = "ov_x";
    static final String KEY_OV_Y = "ov_y";

    /** Dich vu dang chay (cung tien trinh voi Activity) de Activity goi cap nhat nhanh. */
    static volatile ChargeService instance;
    /** Dang mo app: hien overlay xem thu de chinh vi tri/co chu. */
    static volatile boolean preview = false;

    private static final String CH_POWER = "power_v2";
    private static final String CH_IDLE = "idle_v1";
    private static final int NID = 1;
    private static final long POLL_MS = 2000;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private NotificationManager nm;
    private PendingIntent openApp;
    private boolean screenOn = true;
    private boolean foregroundStarted = false;
    private String lastKey = "";
    private WindowManager wm;
    private TextView ov;
    private boolean ovAdded = false;
    private String lastOv = "";

    private final Runnable tick = new Runnable() {
        @Override public void run() { refresh(); }
    };

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String a = intent.getAction();
            if (Intent.ACTION_SCREEN_OFF.equals(a)) screenOn = false;
            else if (Intent.ACTION_SCREEN_ON.equals(a)) screenOn = true;
            refresh();
        }
    };

    static void start(Context c) {
        c.startForegroundService(new Intent(c, ChargeService.class));
    }

    static void stop(Context c) {
        c.stopService(new Intent(c, ChargeService.class));
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        try { nm.deleteNotificationChannel("power_v1"); } catch (Exception ignored) { }
        createChannels();
        openApp = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        screenOn = pm == null || pm.isInteractive();

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_POWER_CONNECTED);
        f.addAction(Intent.ACTION_POWER_DISCONNECTED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(receiver, f);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Bat buoc goi startForeground ngay sau startForegroundService
        if (!foregroundStarted) {
            Notification n = idleNotification();
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(NID, n);
            }
            foregroundStarted = true;
            lastKey = "idle";
        }

        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!p.getBoolean(KEY_ENABLED, false)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        refresh();
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // Nguoi dung vuot tat app khoi da nhiem -> hen gio tu khoi dong lai dich vu
        scheduleRestart();
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(tick);
        removeOverlay();
        instance = null;
        try { unregisterReceiver(receiver); } catch (Exception ignored) { }
        stopForeground(STOP_FOREGROUND_REMOVE);
        // Neu bi he thong dung ngoai y muon (cong tac van BAT) -> tu bat lai
        scheduleRestart();
        ChargeWidget.refresh(this);
        super.onDestroy();
    }

    private void scheduleRestart() {
        try {
            SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
            if (!p.getBoolean(KEY_ENABLED, false)) return;
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (am == null) return;
            PendingIntent pi = PendingIntent.getForegroundService(this, 1,
                    new Intent(this, ChargeService.class),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            long at = SystemClock.elapsedRealtime() + 1500;
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi);
            } else {
                am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ------------------------------------------------------------------

    static void poke() {
        ChargeService s = instance;
        if (s != null) s.refresh();
    }

    private void refresh() {
        handler.removeCallbacks(tick);
        PowerReader.Reading r = PowerReader.read(this);
        boolean active = r.plugged && screenOn;
        updateOverlay(r, active);
        if (active) {
            showPower(r);
            handler.postDelayed(tick, POLL_MS);   // chi lap khi dang sac + man hinh bat
        } else {
            showIdle();                           // khong lap -> 0% CPU
            if (screenOn) ChargeWidget.refresh(this);
        }
    }


    // ------------------- Lop phu noi (overlay) -------------------

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void updateOverlay(PowerReader.Reading r, boolean active) {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        boolean want = p.getBoolean(KEY_ENABLED, false)
                && p.getBoolean(KEY_OVERLAY, false)
                && Settings.canDrawOverlays(this)
                && screenOn
                && (active || preview);
        if (!want) {
            removeOverlay();
            return;
        }

        String text;
        if (!r.plugged) text = "--W";
        else if (!r.valid) text = "?W";
        else if (r.watts >= 10) text = String.format(Locale.US, "%.0fW", r.watts);
        else text = String.format(Locale.US, "%.1fW", r.watts);

        int size = p.getInt(KEY_OV_SIZE, 18);
        int xp = p.getInt(KEY_OV_X, 30);
        int yd = p.getInt(KEY_OV_Y, 0);
        String key = text + "|" + size + "|" + xp + "|" + yd;
        if (ovAdded && key.equals(lastOv)) return;
        lastOv = key;

        try {
            if (ov == null) {
                ov = new TextView(this);
                ov.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
                ov.setTextColor(0xFFFFD60A);
                ov.setIncludeFontPadding(false);
                ov.setPadding(dp(6), dp(2), dp(6), dp(2));
                GradientDrawable g = new GradientDrawable();
                g.setColor(0x99000000);
                g.setCornerRadius(dp(8));
                ov.setBackground(g);
            }
            ov.setTextSize(size);
            ov.setText(text);
            ov.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            int w = ov.getMeasuredWidth();
            int sw = getResources().getDisplayMetrics().widthPixels;

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.x = Math.round(xp / 100f * Math.max(0, sw - w));
            lp.y = dp(yd);
            if (Build.VERSION.SDK_INT >= 30) {
                lp.layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
            }
            if (!ovAdded) {
                wm.addView(ov, lp);
                ovAdded = true;
            } else {
                wm.updateViewLayout(ov, lp);
            }
        } catch (Exception e) {
            ovAdded = false;
            lastOv = "";
        }
    }

    private void removeOverlay() {
        if (ovAdded && ov != null) {
            try { wm.removeView(ov); } catch (Exception ignored) { }
        }
        ovAdded = false;
        lastOv = "";
    }

    private void showPower(PowerReader.Reading r) {
        boolean showW = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_SHOW_W, false);
        String key = (r.valid ? String.format(Locale.US, "p%.1f", r.watts) : "p?") + (showW ? "W" : "");
        if (key.equals(lastKey)) return;
        lastKey = key;
        ChargeWidget.refresh(this);

        String num;
        String title;
        String text;
        if (r.valid) {
            num = String.valueOf(Math.round(r.watts));
            title = String.format(Locale.US, "Đang sạc: %.1f W", r.watts);
            text = String.format(Locale.US, "%d mA · %.2f V", Math.round(r.milliAmps), r.volts);
        } else {
            num = "?";
            title = "Đang sạc (không đọc được dòng sạc)";
            text = "Máy không cung cấp thông tin dòng sạc";
        }

        Notification n = new Notification.Builder(this, CH_POWER)
                .setSmallIcon(textIcon(num, showW))
                .setContentTitle(title)
                .setContentText(text)
                .setOngoing(true)
                .setShowWhen(false)
                .setOnlyAlertOnce(true)
                .setLocalOnly(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setContentIntent(openApp)
                .build();
        nm.notify(NID, n);
    }

    private void showIdle() {
        if ("idle".equals(lastKey)) return;
        lastKey = "idle";
        nm.notify(NID, idleNotification());
    }

    private Notification idleNotification() {
        return new Notification.Builder(this, CH_IDLE)
                .setSmallIcon(R.drawable.ic_idle)
                .setContentTitle("Check Sạc đang chờ")
                .setContentText("Cắm sạc và bật màn hình để xem công suất")
                .setOngoing(true)
                .setShowWhen(false)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setContentIntent(openApp)
                .build();
    }

    private void createChannels() {
        NotificationChannel power = new NotificationChannel(
                CH_POWER, "Công suất sạc (hiện trên thanh trạng thái)",
                NotificationManager.IMPORTANCE_DEFAULT);
        power.setShowBadge(false);
        power.setSound(null, null);
        power.enableVibration(false);
        power.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(power);

        NotificationChannel idle = new NotificationChannel(
                CH_IDLE, "Chờ cắm sạc (ẩn)",
                NotificationManager.IMPORTANCE_MIN);
        idle.setShowBadge(false);
        idle.setSound(null, null);
        idle.enableVibration(false);
        nm.createNotificationChannel(idle);
    }

    /** Ve so cong suat thanh icon trang: cao het co (96px), ep be ngang neu can. Chu W nho (co the an). */
    private static Icon textIcon(String num, boolean withW) {
        final int size = 96;
        final float avail = size - 2f;
        Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);

        Typeface tf = Typeface.create("sans-serif-condensed", Typeface.BOLD);
        Paint pn = new Paint(Paint.ANTI_ALIAS_FLAG);
        pn.setColor(Color.WHITE);
        pn.setTypeface(tf);
        Paint pw = new Paint(pn);

        final float base = 100f;
        final float wRatio = 0.55f;
        pn.setTextSize(base);
        Rect rb = new Rect();
        pn.getTextBounds(num, 0, num.length(), rb);

        // 1) chinh co chu de chieu cao so = avail
        float k = avail / rb.height();
        pn.setTextSize(base * k);
        pw.setTextSize(base * k * wRatio);

        // 2) neu qua rong thi ep be ngang (chu van cao het co)
        float total = pn.measureText(num) + (withW ? pw.measureText("W") : 0f);
        float sx = Math.min(1f, avail / total);
        pn.setTextScaleX(sx);
        pw.setTextScaleX(sx);

        float nw = pn.measureText(num);
        float ww = withW ? pw.measureText("W") : 0f;
        float x = (size - (nw + ww)) / 2f;
        float y = size / 2f - (rb.top + rb.bottom) / 2f * k;

        c.drawText(num, x, y, pn);
        if (withW) c.drawText("W", x + nw, y, pw);
        return Icon.createWithBitmap(bmp);
    }
}
